#!/usr/bin/env bash
set -euo pipefail

echo "=== Building AstraShop ==="

if ! command -v mvn >/dev/null 2>&1; then
  echo "Maven is not installed or not on your PATH."
  echo "  - macOS:   brew install maven"
  echo "  - Debian/Ubuntu: sudo apt install maven"
  echo "  - Windows: https://maven.apache.org/download.cgi (add bin/ to PATH)"
  exit 1
fi

if ! command -v java >/dev/null 2>&1; then
  echo "Java is not installed or not on your PATH. Java 21 is required."
  exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | head -n1 | sed -E 's/.*"([0-9]+).*/\1/')
if [ "${JAVA_VERSION}" -lt 21 ] 2>/dev/null; then
  echo "Warning: detected Java ${JAVA_VERSION}, but AstraShop targets Java 21."
  echo "The build may fail. Install a Java 21 JDK (e.g. Temurin 21) if so."
fi

mvn -q clean package

JAR=$(find target -maxdepth 1 -name "AstraShop-*.jar" | head -n1)

if [ -n "${JAR}" ]; then
  echo ""
  echo "=== Build successful ==="
  echo "Jar: ${JAR}"
  echo ""
  echo "Copy it, Vault.jar, and EssentialsX.jar into your server's plugins/ folder,"
  echo "start the server once to generate config files, then edit and /astrashop reload."
else
  echo "Build finished but no jar was found in target/ — check the Maven output above."
  exit 1
fi
